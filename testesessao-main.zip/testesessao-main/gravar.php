<?session_start();$nome = $_POST[nome];$_SESSION[nome] = $nome;?><script language="JavaScript" type="text/javascript">            location.href="mostrar.php";     </script>
