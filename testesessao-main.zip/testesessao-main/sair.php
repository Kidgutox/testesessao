<?
session_start();
// sesion_unset();
session_destroy();
 
//prontinho acima acabamos com todas as sessões existentes!
echo "<font size=5><center><br><br><br>Voce saiu com sucesso!</center></font>";
?>
<!DOCTYPE html>
<html>
<body background="https://i.ytimg.com/vi/ZPjHlGWHZio/maxresdefault.jpg" text="white">
</form>
</br>
<p></p>
<form method="POST" action="index.php" style="font-size:30px; text-align:center;">
<input type="submit" value="Voltar" style="font-size:30px;">
</form>
</body>
</html>
