<html>
<body background="https://i.ytimg.com/vi/ZPjHlGWHZio/maxresdefault.jpg" text="white">
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<form method="POST" action="gravar.php" style="font-size:30px; text-align:center;">  Nome: 
<input type="text" name="nome" size="30">
</p>  <p>
<input style="font-size:30px" type="submit" value="Enviar">
</p>
</form>
</body>
</html>
